const buttonAdicionar = document.querySelector("#adicionar");

const convidados = [];

const listaConvidados = document.querySelector("#lista-convidados");

const totalConfirmados = document.querySelector("#total-confirmados");
let confirmado = 0;

const totalCrianca = document.querySelector("#total-criancas");
let crianca = 0;

const totalAdulto = document.querySelector("#total-adultos");
let adulto = 0;

buttonAdicionar.addEventListener("click", () => {
    let nomeConvidado = prompt("Digite o nome do(a) convidado(a):");

    if(nomeConvidado == "") {
        alert("Para adiocionar um convidado(a), precisa digitar um nome e idade!");
        return;
    }

    let idadeConvidado = Number(prompt("Digite a idade do(a) convidado(a):"));

    if(idadeConvidado == "") {
        alert("Para adicionar completamente, precisa digitar a idade do convidado(a)!");
        return;
    } else {
        if(idadeConvidado < 0) {
            alert("Idade inválida!");
            return;
        }
    }

    const convidado = {
        nome: nomeConvidado,
        idade: idadeConvidado
    };
    
    convidados.push(convidado);

    const trLista = document.createElement("tr");
    const tdNome = document.createElement("td");
    const tdIdade = document.createElement("td");
    const tdStatus = document.createElement("td");

    tdNome.textContent = convidado.nome;
    tdIdade.textContent = convidado.idade;
    tdStatus.textContent = "Pendente";
    tdStatus.style.backgroundColor = "yellow";

    tdNome.addEventListener("click", () => {
        if(tdStatus.textContent == "Não") {
            tdStatus.textContent = "Confirmado";
            tdStatus.style.backgroundColor = "green";
            tdStatus.style.color = "white"; 
            
            confirmado++;
            totalConfirmados.textContent = confirmado;
        }
    });
    
    tdNome.addEventListener("dblclick", () => {
        if(tdStatus.textContent == "Confirmado") {
            confirmado--;
            totalConfirmados.textContent = confirmado;
        }
    
        tdStatus.textContent = "Não";
        tdStatus.style.backgroundColor = "red";
        tdStatus.style.color = "white";
    });
    
    trLista.appendChild(tdNome);
    trLista.appendChild(tdIdade);
    trLista.appendChild(tdStatus);
    listaConvidados.appendChild(trLista);

    const totalConvidados = document.querySelector("#total-convidados");
    totalConvidados.textContent = convidados.length;
    
    
    if(convidado.idade <= 12) {
        crianca++;
        totalCrianca.textContent = crianca;
    } else {
        adulto++;
        totalAdulto.textContent = adulto;
    }
});